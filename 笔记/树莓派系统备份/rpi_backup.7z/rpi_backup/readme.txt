



脚本地址
https://github.com/nanhantianyi/rpi-backup/blob/master/back.sh


挂载u盘
sudo mount /dev/sda1 /media/

备份系统
sudo bash back.sh /media/backup.img

系统扩容
sudo bash resize.sh


